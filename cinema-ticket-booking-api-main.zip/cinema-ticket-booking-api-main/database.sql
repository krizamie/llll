
CREATE DATABASE IF NOT EXISTS CinemaTicketBooking;

USE CinemaTicketBooking;

CREATE TABLE Customer (
    customer_id INT NOT NULL AUTO_INCREMENT,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(20) NOT NULL,
    PRIMARY KEY (customer_id)
);

CREATE TABLE Movie (
    movie_id INT NOT NULL AUTO_INCREMENT,
    title VARCHAR(150) NOT NULL,
    genre VARCHAR(50) NOT NULL,
    duration_minutes INT NOT NULL,
    release_date DATE NOT NULL,
    rating VARCHAR(10),
    PRIMARY KEY (movie_id)
);

CREATE TABLE Cinema (
    cinema_id INT NOT NULL AUTO_INCREMENT,
    cinema_name VARCHAR(100) NOT NULL,
    location VARCHAR(150) NOT NULL,
    PRIMARY KEY (cinema_id)
);

CREATE TABLE Seat (
    seat_id INT NOT NULL AUTO_INCREMENT,
    cinema_id INT NOT NULL,
    seat_number VARCHAR(10) NOT NULL,
    seat_type VARCHAR(30) DEFAULT 'Regular',
    PRIMARY KEY (seat_id),
    CONSTRAINT fk_seat_cinema
        FOREIGN KEY (cinema_id)
        REFERENCES Cinema(cinema_id),
    CONSTRAINT uq_seat
        UNIQUE (cinema_id, seat_number)
);

CREATE TABLE Showtime (
    showtime_id INT NOT NULL AUTO_INCREMENT,
    movie_id INT NOT NULL,
    cinema_id INT NOT NULL,
    show_date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    ticket_price DECIMAL(10,2) NOT NULL DEFAULT 250.00,
    PRIMARY KEY (showtime_id),
    CONSTRAINT fk_showtime_movie
        FOREIGN KEY (movie_id)
        REFERENCES Movie(movie_id),
    CONSTRAINT fk_showtime_cinema
        FOREIGN KEY (cinema_id)
        REFERENCES Cinema(cinema_id)
);

CREATE TABLE Ticket (
    ticket_id INT NOT NULL AUTO_INCREMENT,
    customer_id INT NOT NULL,
    showtime_id INT NOT NULL,
    seat_id INT NOT NULL,
    booking_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ticket_status VARCHAR(30) DEFAULT 'Reserved',
    PRIMARY KEY (ticket_id),
    CONSTRAINT fk_ticket_customer
        FOREIGN KEY (customer_id)
        REFERENCES Customer(customer_id),
    CONSTRAINT fk_ticket_showtime
        FOREIGN KEY (showtime_id)
        REFERENCES Showtime(showtime_id),
    CONSTRAINT fk_ticket_seat
        FOREIGN KEY (seat_id)
        REFERENCES Seat(seat_id),
    CONSTRAINT uq_showtime_seat
        UNIQUE (showtime_id, seat_id)
);

CREATE TABLE Payment (
    payment_id INT NOT NULL AUTO_INCREMENT,
    ticket_id INT NOT NULL,
    payment_method VARCHAR(30) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_status VARCHAR(30) DEFAULT 'Pending',
    payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (payment_id),
    CONSTRAINT fk_payment_ticket
        FOREIGN KEY (ticket_id)
        REFERENCES Ticket(ticket_id),
    CONSTRAINT uq_payment_ticket
        UNIQUE (ticket_id)
);
