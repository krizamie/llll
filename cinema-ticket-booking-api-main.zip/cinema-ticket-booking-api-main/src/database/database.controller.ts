
import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Param,
  Body,
  BadRequestException,
  NotFoundException,
} from '@nestjs/common';
import { DatabaseService } from './database.service';

const TABLES: Record<
  string,
  {
    name: string;
    id: string;
    columns: string[];
  }
> = {
  customer: {
    name: 'Customer',
    id: 'customer_id',
    columns: ['first_name', 'last_name', 'email', 'phone'],
  },
  movie: {
    name: 'Movie',
    id: 'movie_id',
    columns: [
      'title',
      'genre',
      'duration_minutes',
      'release_date',
      'rating',
    ],
  },
  cinema: {
    name: 'Cinema',
    id: 'cinema_id',
    columns: ['cinema_name', 'location'],
  },
  seat: {
    name: 'Seat',
    id: 'seat_id',
    columns: ['cinema_id', 'seat_number', 'seat_type'],
  },
  showtime: {
    name: 'Showtime',
    id: 'showtime_id',
    columns: [
      'movie_id',
      'cinema_id',
      'show_date',
      'start_time',
      'end_time',
      'ticket_price',
    ],
  },
  ticket: {
    name: 'Ticket',
    id: 'ticket_id',
    columns: [
      'customer_id',
      'showtime_id',
      'seat_id',
      'booking_date',
      'ticket_status',
    ],
  },
  payment: {
    name: 'Payment',
    id: 'payment_id',
    columns: [
      'ticket_id',
      'payment_method',
      'amount',
      'payment_status',
      'payment_date',
    ],
  },
};

@Controller('api')
export class DatabaseController {
  constructor(private readonly database: DatabaseService) {}

  @Get('test-connection')
  async testConnection() {
    return this.database.query('SELECT 1 AS connected');
  }

  private getTable(table: string) {
    const config = TABLES[table.toLowerCase()];

    if (!config) {
      throw new NotFoundException('Table not found');
    }

    return config;
  }

  private validateBody(
    body: any,
    config: { name: string; id: string; columns: string[] },
  ): string[] {
    if (
      !body ||
      typeof body !== 'object' ||
      Array.isArray(body)
    ) {
      throw new BadRequestException(
        'Request body must be an object',
      );
    }

    const keys = Object.keys(body);

    if (
      keys.length === 0 ||
      keys.some((key) => !config.columns.includes(key))
    ) {
      throw new BadRequestException('Invalid or empty fields');
    }

    return keys;
  }

  @Get(':table')
  async findAll(@Param('table') table: string) {
    const config = this.getTable(table);

    return this.database.query(
      `SELECT * FROM \`${config.name}\` ORDER BY \`${config.id}\` DESC`,
    );
  }

  @Get(':table/:id')
  async findOne(
    @Param('table') table: string,
    @Param('id') id: string,
  ) {
    const config = this.getTable(table);

    const result = (await this.database.query(
      `SELECT * FROM \`${config.name}\` WHERE \`${config.id}\` = ?`,
      [id],
    )) as any[];

    if (result.length === 0) {
      throw new NotFoundException('Record not found');
    }

    return result[0];
  }

  @Post(':table')
  async create(
    @Param('table') table: string,
    @Body() body: any,
  ) {
    const config = this.getTable(table);
    const keys = this.validateBody(body, config);
    const columns = keys
      .map((key) => `\`${key}\``)
      .join(', ');
    const placeholders = keys.map(() => '?').join(', ');
    const values = keys.map((key) => body[key]);

    return this.database.query(
      `INSERT INTO \`${config.name}\` (${columns}) VALUES (${placeholders})`,
      values,
    );
  }

  @Put(':table/:id')
  async update(
    @Param('table') table: string,
    @Param('id') id: string,
    @Body() body: any,
  ) {
    const config = this.getTable(table);
    const keys = this.validateBody(body, config);
    const setClause = keys
      .map((key) => `\`${key}\` = ?`)
      .join(', ');
    const values = keys.map((key) => body[key]);

    const result = (await this.database.query(
      `UPDATE \`${config.name}\` SET ${setClause} WHERE \`${config.id}\` = ?`,
      [...values, id],
    )) as any;

    if (result.affectedRows === 0) {
      throw new NotFoundException(
        'Record not found or no changes made',
      );
    }

    return {
      message: 'Record updated successfully',
      affectedRows: result.affectedRows,
    };
  }

  @Delete(':table/:id')
  async remove(
    @Param('table') table: string,
    @Param('id') id: string,
  ) {
    const config = this.getTable(table);

    const result = (await this.database.query(
      `DELETE FROM \`${config.name}\` WHERE \`${config.id}\` = ?`,
      [id],
    )) as any;

    if (result.affectedRows === 0) {
      throw new NotFoundException('Record not found');
    }

    return {
      message: 'Record deleted successfully',
      affectedRows: result.affectedRows,
    };
  }
}
