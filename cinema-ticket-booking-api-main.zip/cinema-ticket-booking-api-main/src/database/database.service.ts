
import {
  Injectable,
  OnModuleDestroy,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import {
  createPool,
  Pool,
  QueryResult,
  ExecuteValues,
} from 'mysql2/promise';
import { readFileSync } from 'fs';
import { join } from 'path';

@Injectable()
export class DatabaseService implements OnModuleDestroy {
  private readonly pool: Pool;

  constructor(private readonly configService: ConfigService) {
    this.pool = createPool({
      host: this.configService.get<string>('DB_HOST'),
      port: Number(
        this.configService.get<string>('DB_PORT', '27588'),
      ),
      user: this.configService.get<string>('DB_USER'),
      password: this.configService.get<string>('DB_PASSWORD'),
      database: this.configService.get<string>(
        'DB_NAME',
        'CinemaTicketBooking',
      ),
      ssl: {
        ca: readFileSync(
          join(process.cwd(), 'certs', 'ca.pem'),
        ),
        rejectUnauthorized: true,
      },
      connectTimeout: 20000,
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0,
    });
  }

  async query(
    sql: string,
    values: ExecuteValues[] = [],
  ): Promise<QueryResult> {
    const [result] = await this.pool.execute(sql, values);
    return result as QueryResult;
  }

  async onModuleDestroy(): Promise<void> {
    await this.pool.end();
  }
}
